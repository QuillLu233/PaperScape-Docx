import { useCallback, useEffect, useRef, useState } from 'react';
import {
  currentMonitor,
  getCurrentWindow,
  type PhysicalPosition,
  type PhysicalSize,
} from '@tauri-apps/api/window';
import {
  closeWindow,
  isTauriEnvironment,
  isWindowFullscreen,
  minimizeWindow,
  toggleFullscreenWindow,
} from '../lib/window';

interface SavedBounds {
  position: PhysicalPosition;
  size: PhysicalSize;
}

export function useWindowState() {
  const [isMaximized, setIsMaximized] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDesktop, setIsDesktop] = useState(isTauriEnvironment);
  const customMaximizedRef = useRef(false);
  const savedBoundsRef = useRef<SavedBounds | null>(null);

  useEffect(() => {
    if (!isTauriEnvironment()) return;
    const windowApi = getCurrentWindow();
    let cancelled = false;
    let unlisten: (() => void) | undefined;

    windowApi
      .isMaximized()
      .then((value) => {
        if (!cancelled) {
          customMaximizedRef.current = false;
          setIsMaximized(value);
        }
      })
      .catch(() => {
        if (!cancelled) setIsDesktop(false);
      });

    void isWindowFullscreen()
      .then((value) => {
        if (!cancelled) setIsFullscreen(value);
      })
      .catch(() => undefined);

    windowApi
      .onResized(() => {
        if (!cancelled && !customMaximizedRef.current) {
          windowApi
            .isMaximized()
            .then((value) => {
              if (!cancelled) setIsMaximized(value);
            })
            .catch(() => undefined);
        }
        void isWindowFullscreen()
          .then((value) => {
            if (!cancelled) setIsFullscreen(value);
            if (!cancelled && !value) {
              void windowApi.setAlwaysOnTop(false).catch(() => undefined);
            }
          })
          .catch(() => undefined);
      })
      .then((stop) => {
        if (cancelled) stop();
        else unlisten = stop;
      })
      .catch(() => undefined);

    return () => {
      cancelled = true;
      unlisten?.();
    };
  }, []);

  useEffect(() => {
    if (!isDesktop) return;
    const windowApi = getCurrentWindow();
    void windowApi.setShadow(!isMaximized && !isFullscreen).catch(() => undefined);
  }, [isDesktop, isFullscreen, isMaximized]);

  const toggleMaximize = useCallback(async () => {
    const windowApi = getCurrentWindow();

    if (customMaximizedRef.current) {
      customMaximizedRef.current = false;
      const saved = savedBoundsRef.current;
      savedBoundsRef.current = null;
      if (saved) {
        await windowApi.setPosition(saved.position);
        await windowApi.setSize(saved.size);
      } else if (await windowApi.isMaximized()) {
        await windowApi.unmaximize();
      }
      // WebView2 can keep the previous surface size until the window is
      // activated after a programmatic resize.
      await windowApi.setFocus().catch(() => undefined);
      setIsMaximized(false);
      return;
    }

    // A native maximized WebView2 window can enter a DWM composition path that
    // stutters while scrolling. Fill the monitor work area with a normal
    // borderless window instead: it looks maximized, keeps the taskbar, but
    // retains the smooth windowed WebView2 path.
    if (await windowApi.isMaximized()) {
      await windowApi.unmaximize();
      setIsMaximized(false);
      return;
    }

    const monitor = await currentMonitor();
    if (!monitor) return;

    savedBoundsRef.current = {
      position: await windowApi.outerPosition(),
      size: await windowApi.outerSize(),
    };
    customMaximizedRef.current = true;
    await windowApi.setPosition(monitor.workArea.position);
    await windowApi.setSize(monitor.workArea.size);
    // Activate after resizing so WebView2 immediately adopts the new viewport.
    await windowApi.setFocus().catch(() => undefined);
    setIsMaximized(true);
  }, []);

  const minimize = useCallback(async () => {
    await minimizeWindow();
  }, []);

  const close = useCallback(async () => {
    await closeWindow();
  }, []);

  const toggleFullscreen = useCallback(async () => {
    await toggleFullscreenWindow();
    setIsFullscreen(await isWindowFullscreen());
  }, []);

  return { isMaximized, isFullscreen, isDesktop, minimize, toggleMaximize, toggleFullscreen, close };
}
